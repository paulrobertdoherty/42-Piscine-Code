/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdoherty <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/25 17:44:27 by pdoherty          #+#    #+#             */
/*   Updated: 2018/06/26 17:46:44 by pdoherty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		lower_case_letter(char c)
{
	return (c > 96 && c < 123) || (c > 47 && c < 58);
}

int		upper_case_letter(char c)
{
	return (c > 64 && c < 91);
}

void	helper(char *str, int *is_word, int i)
{
	if (*is_word == 0)
	{
		if (str[i] <= 47 || str[i] >= 58)
			str[i] -= 32;
		*is_word = 1;
	}
}

char	*ft_strcapitalize(char *str)
{
	int i;
	int is_word;

	i = 0;
	while (str[i])
	{
		if (upper_case_letter(str[i]))
			str[i] += 32;
		i++;
	}
	i = 0;
	is_word = 0;
	while (str[i])
	{
		if (lower_case_letter(str[i]))
		{
			helper(str, &is_word, i);
		}
		else if (is_word)
		{
			is_word = 0;
		}
		i++;
	}
	return (str);
}
