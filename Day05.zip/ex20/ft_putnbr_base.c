/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdoherty <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/25 23:24:24 by pdoherty          #+#    #+#             */
/*   Updated: 2018/06/26 16:14:44 by pdoherty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

short	length(char *str)
{
	short i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int		first_char(int num, short base_length)
{
	int i;

	i = num;
	while (i < base_length)
		i /= base_length;
	return i;
}

int		next_chars(int num, short base_length)
{
	int i;
	int m;

	i = num;
	m = 1;
	while (i < base_length)
	{
		i /= base_length;
		m *= base_length;
	}
	return num - (i * m);
}

void	ft_putnbr_base_rec(int nbr, char *base, short base_length)
{
	if (nbr < 0)
	{
		ft_putchar('-');
		if (nbr == -2147483648)
		{
			ft_putchar(base[first_char(2147483647, base_length) % base_length]);
			ft_putnbr_base_rec(next_chars(2147483647, base_length), base, base_length);
		}
		else
		{
			ft_putnbr_base_rec(-1 * nbr, base, base_length);
		}
	}
	if (nbr >= base_length)
	{
		ft_putnbr_base_rec(nbr / base_length, base, base_length);
		ft_putchar(base[nbr % base_length]);
	}
	else
	{
		ft_putchar(base[nbr]);
	}
}

void	ft_putnbr_base(int nbr, char *base)
{
	ft_putnbr_base_rec(nbr, base, length(base));
}
