/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdoherty <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/26 11:30:47 by pdoherty          #+#    #+#             */
/*   Updated: 2018/06/26 11:30:50 by pdoherty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int length(char *str)
{
	int i;

	i = 0;
	while (str[i])
		i++;
	return i;
}

int	index_of(char *str, char c)
{
	int i;

	i = 0;
	while (str[i])
	{
		if (str[i] == c)
			return i;
	}
	return -1;
}

int	ft_atoi(char *str, char *base)
{
	int tr;
	int i;
	int base_length;

	tr = 0;
	i = 0;
	base_length = length(base);
	if (str[0] == '-')
		ft_putchar('-');
	while (str[i])
	{
		tr = (tr * 10) + index_of(str[i]);
		i++;
	}
	if (str[0] == '-')
		tr *= -1;
	return (tr);
}
