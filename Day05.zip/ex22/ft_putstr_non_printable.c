/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdoherty <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/26 14:31:33 by pdoherty          #+#    #+#             */
/*   Updated: 2018/06/26 17:58:06 by pdoherty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	print_hex(char c)
{
	int		i;
	char	*hex;

	hex = "0123456789abcdef";
	i = c;
	while (i > 0)
	{
		ft_putchar(hex[i % 16]);
		i /= 16;
	}
}

void	ft_putstr_non_printable(char *str)
{
	if (str[0])
	{
		if (str[0] < 32)
		{
			ft_putchar('\\');
			print_hex(str[0]);
		}
		else
		{
			ft_putchar(str[0]);
		}
		ft_putstr_non_printable(&str[1]);
	}
}
