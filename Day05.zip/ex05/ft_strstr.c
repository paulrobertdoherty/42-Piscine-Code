/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdoherty <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/26 22:53:13 by pdoherty          #+#    #+#             */
/*   Updated: 2018/06/26 22:53:28 by pdoherty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	increment(int *i, int *j, int *index)
{
	if (*j == 0)
		*index = *i;
	*j = *j + 1;
}

void	set_to_zero(int *j, int *index)
{
	*j = 0;
	*index = 0;
}

char	*final_test(char *str, char *to_find, int j, int index)
{
	if (to_find[j] == 0)
		return (&str[index]);
	return (0);
}

char	*ft_strstr(char *str, char *to_find)
{
	int i;
	int j;
	int index;

	i = 0;
	j = 0;
	index = 0;
	while (str[i])
	{
		if (str[i] == to_find[j])
		{
			increment(&i, &j, &index);
		}
		else if (to_find[j] == 0)
		{
			return (&str[index]);
		}
		else
		{
			set_to_zero(&j, &index);
		}
		i++;
	}
	return (final_test(str, to_find, j, index));
}
